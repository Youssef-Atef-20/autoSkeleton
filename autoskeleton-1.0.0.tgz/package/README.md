# AutoSkeleton Loader Library

`autoskeleton` is a lightweight React library that automatically generates realistic skeleton loading placeholders by traversing and analyzing existing React component trees.

Instead of manually creating separate skeleton components for every UI section developers can simply wrap their components using:

```jsx
<AutoSkeleton loading={loading}>
   <ProductCard />
</AutoSkeleton>
```

The library automatically:
- detects layout structure
- replaces elements with matching skeletons
- preserves spacing and alignment
- supports multiple animations
- generates organic loading placeholders

---

# Tech Stack

- React
- Vite
- JavaScript
- CSS
- npm package

---

# Main Goals

- Eliminate manual skeleton creation
- Preserve exact UI layout during loading
- Keep API extremely simple
- Provide high performance traversal
- Publish production ready npm package

---

# Installation

```bash
npm install autoskeleton
```

---

# Quick Start

## Import styles

```js
import "autoskeleton/dist/style.css";
```

## Basic Usage

```jsx
import { AutoSkeleton } from "autoskeleton";

function App() {
   return (
      <AutoSkeleton loading={true}>
         <ProductCard />
      </AutoSkeleton>
   );
}
```

## Advanced Usage

```jsx
<AutoSkeleton
   loading={loading}
   animation="shimmer"
   duration={1.5}
   theme="light"
>
   <Dashboard />
</AutoSkeleton>
```

---

# Supported Animations

- shimmer
- pulse
- wave
- none

---

# Supported Elements

Initial MVP should support:

- div
- section
- article
- img
- button
- input
- textarea
- p
- span
- h1-h6

---

# Manual Skeleton Directives

## Ignore specific elements

```jsx
<div data-skeleton-ignore="true">
   Static content
</div>
```

This prevents skeleton replacement for that subtree.

---

## Override detection type

```jsx
<div data-skeleton="circle"></div>
```

Supported override types:
- text
- image
- circle
- button
- input

---

# Expected Folder Structure

```bash
src/
├── components/
│   ├── AutoSkeleton.jsx
│   └── SkeletonElement.jsx
│
├── utils/
│   ├── traverse.jsx
│   ├── detectType.js
│   ├── sizeEstimator.js
│   └── cloneWithSkeleton.jsx
│
├── hooks/
│   └── useSkeletonConfig.js
│
├── constants/
│   └── elementMap.js
│
├── styles/
│   └── skeleton.css
│
└── index.js
```

---

# File Responsibilities

## components/AutoSkeleton.jsx

Main wrapper component.

Responsibilities:
- receives children
- checks loading state
- starts traversal process
- passes configuration

---

## components/SkeletonElement.jsx

Reusable skeleton block component.

Responsibilities:
- render shimmer block
- support pulse animations
- support dynamic dimensions
- support custom radius

---

## utils/traverse.jsx

Core traversal engine.

Responsibilities:
- recursively traverse React nodes
- preserve layout structure
- replace elements with skeletons
- detect containers and leaf nodes

---

## utils/detectType.js

Responsible for detecting element categories.

Examples:
- img -> image
- h1 -> text
- button -> button

---

## utils/sizeEstimator.js

Responsible for estimating realistic sizes.

Examples:
- paragraph line count
- title widths
- button dimensions
- image sizing

---

## utils/cloneWithSkeleton.jsx

Clones original containers while replacing children with skeleton placeholders.

---

## hooks/useSkeletonConfig.js

Normalizes and stores configuration options.

---

## constants/elementMap.js

Contains central HTML element mappings.

---

## styles/skeleton.css

Contains:
- shimmer animation
- pulse animation
- wave animation
- dark mode support

---

# Traversal Flow

```bash
AutoSkeleton
   ↓
traverseTree()
   ↓
detectType()
   ↓
estimateSize()
   ↓
generate SkeletonElement
   ↓
render final skeleton tree
```

---

# Core Features

## Automatic Structure Traversal

The library should deeply traverse:
- native HTML elements
- custom React components
- nested containers

and generate matching skeleton placeholders.

---

## Layout Preservation

The generated skeleton must preserve:
- flex layouts
- grid layouts
- spacing
- padding
- margins
- alignment
- widths
- heights
- border radius

---

## Organic Text Generation

Paragraphs should generate multiple lines with varying widths to simulate realistic content.

Example:
- first line 100%
- second line 92%
- last line 65%

---

## Animation Engine

Support configurable animation styles:

```jsx
<AutoSkeleton animation="pulse" />
```

Animation duration should be configurable.

---

# MVP Requirements

The first production version should:

- work reliably
- support recursive traversal
- preserve layouts
- support animations
- be npm publishable
- support React 18+

Avoid overengineering.

Focus on:
- traversal quality
- layout preservation
- developer experience

---

# Future Roadmap

## Phase 2

- TailwindCSS class detection
- circular avatar auto detection
- multiline paragraph intelligence
- dark mode improvements
- TypeScript definitions

---

## Phase 3

- Next.js optimization
- responsive prediction
- advanced width heuristics
- theme presets

---

## Phase 4

AI assisted skeleton prediction:
- component hierarchy analysis
- smart placeholder inference
- advanced UI prediction

---

# Vite Requirements

Use Vite library mode.

Requirements:
- externalize react and react-dom
- generate esm and cjs bundles
- optimize bundle size
- support tree shaking

---

# npm Publishing Requirements

The project should include:
- package.json
- README.md
- LICENSE
- example usage
- production build config
- npm ready exports

---

# Final Goal

The developer experience should feel magical.

A developer writes:

```jsx
<AutoSkeleton loading={loading}>
   <ComplexComponent />
</AutoSkeleton>
```

And instantly receives a realistic loading skeleton automatically with almost zero manual work.
